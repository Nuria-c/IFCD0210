document.getElementById('opacidad').addEventListener('click', function() {
    var box = document.getElementById('opacidad');
    var currentOpacity = window.getComputedStyle(box).opacity;

// La siguiente condición es para establecer la opacidad final

if (currentOpacity === '1') {
    box.style.opacity = '0.5';
} else {
    box.style.opacity = '1';
}
});