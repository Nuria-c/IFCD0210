document.getElementById('boton').addEventListener('click', function() {
    var box = document.getElementById('boton');
    var currentColor = box.style.backgroundColor;

// La siguiente condición es para establecer el color final
if (currentColor==='rgb(52,152,219)' || currentColor===''){
    box.style.backgroundColor = 'red';
    box.style.color = 'black';
}else{
    box.style.backgroundColor = 'green';
    box.style.color = 'white'; //estos serían los colores iniciales
}
}
);