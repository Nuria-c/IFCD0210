document.addEventListener("DOMContentLoaded",() => {
    const caja1 = document.getElementById("caja1");

    caja1.addEventListener("click", () => {
        fadeOut (caja1, 2000); //Desvanece en 2 segundos
    });
});

function fadeOut(element, duration) {
    let opacity = 1;
    const interval = 50;
    const fadeStep = interval / duration;

    const fadeEffect = setInterval(() => {
        if (opacity <= 0) {
            clearInterval(fadeEffect);
            element.style.display = "none"; //Cuando la opacidad llega a 0, se oculta el elemento
        } else {
            opacity -= fadeStep;
            element.style.opacity = opacity;
        }
        }, interval);
    }