var bola = document.getElementById('bola');
var posX = 0;
var posY = 0;
var veloX = 4;
var veloY = 4;

function animate() {
    posX += veloX;
    posY += veloY;

// Detectar el golpe en las paredes superior e inferior y cambiar la dirección
    if (posX + bola.offsetHeight > window.innerWidth || posX < 0) {
        veloX = -veloX;
    }

// Detectar el golpe en las pareces laterales y cambiar la dirección
    if (posY + bola.offsetHeight > window.innerHeight || posY < 0) {
        veloY = -veloY;
    }

    bola.style.left = posX + 'px';
    bola.style.top = posY + 'px';

    requestAnimationFrame(animate);
}
animate();